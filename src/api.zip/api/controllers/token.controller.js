import { asyncHandler } from "../../common/error.js";
import {
  verifyAccessToken,
  refreshAccessToken
} from "../services/token.service.js";

export const verifyAccessTokenController = asyncHandler(async (req, res) => {
  const result = await verifyAccessToken(req.auth.userId);
  res.status(200).json({
    message: "Access Token 유효함",
    data: result,
  });
});

export const refreshTokenController = asyncHandler(async (req, res) => {
  const refreshToken = req.cookies?.refreshToken;
  const result = await refreshAccessToken(refreshToken);

  res.cookie("refreshToken", result.refreshToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: process.env.NODE_ENV === "production" ? "strict" : "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });

  res.status(200).json({
    message: "Access Token 재발급 성공",
    accessToken: result.accessToken,
    user: result.user,
  });
});
